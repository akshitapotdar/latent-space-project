"""
FID (Frechet Inception Distance) score computation.

Used for the quantitative results table in slide 16
(GAN: 27.3, VAE: 145.16).

We use the `pytorch-fid` package — install with:
    pip install pytorch-fid

Usage:
    fid = compute_fid(real_dir="./real_images", fake_dir="./generated_images")
"""
import os
import subprocess


def compute_fid(real_dir: str, fake_dir: str, batch_size: int = 50, dims: int = 2048):
    """
    Run pytorch-fid as a subprocess and parse the result.

    Both directories must contain image files (PNG/JPG) and have
    enough samples (typically 10k+ for a stable FID).
    """
    if not os.path.isdir(real_dir):
        raise FileNotFoundError(f"real_dir not found: {real_dir}")
    if not os.path.isdir(fake_dir):
        raise FileNotFoundError(f"fake_dir not found: {fake_dir}")

    cmd = [
        "python", "-m", "pytorch_fid",
        real_dir, fake_dir,
        "--batch-size", str(batch_size),
        "--dims", str(dims),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    # pytorch-fid prints "FID:  <number>"
    for line in result.stdout.splitlines():
        if line.strip().startswith("FID:"):
            return float(line.split(":")[1].strip())
    raise RuntimeError(f"Could not parse FID from output:\n{result.stdout}")


def mse(x_pred, x_true):
    """Pixel-wise MSE — used for the inverse-problem quantitative table."""
    import torch
    return torch.mean((x_pred - x_true) ** 2).item()
