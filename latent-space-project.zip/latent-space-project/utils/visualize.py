"""
Visualization helpers — re-creates the figures in the presentation.
"""
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.stats import norm


@torch.no_grad()
def plot_latent_manifold(
    decoder,
    *,
    n: int = 20,
    image_size: int = 28,
    device: str = "cpu",
    title: str = "2D Latent Space Manifold",
    save_path: str = None,
    z_range: tuple = (-1.64, 1.64),
):
    """
    Sweep a 2D latent grid and decode each point. Reproduces the
    latent-manifold figures in slides 9 (VAE) and 10 (GAN).

    The default range matches the presentation: z values are taken
    at evenly-spaced quantiles of N(0, 1) between -1.64 and 1.64.
    """
    # Use Gaussian quantiles so the grid samples the regions where
    # the model has actually seen training data
    grid_x = norm.ppf(np.linspace(0.05, 0.95, n))
    grid_y = norm.ppf(np.linspace(0.05, 0.95, n))

    canvas = np.zeros((n * image_size, n * image_size))

    decoder.eval()
    for i, yi in enumerate(grid_y):
        for j, xi in enumerate(grid_x):
            z = torch.tensor([[xi, yi]], dtype=torch.float32, device=device)
            x_decoded = decoder(z).cpu().numpy()
            canvas[
                i * image_size : (i + 1) * image_size,
                j * image_size : (j + 1) * image_size,
            ] = x_decoded.reshape(image_size, image_size)

    fig, ax = plt.subplots(figsize=(10, 10))
    ax.imshow(canvas, cmap="gray")
    ax.set_title(title)
    ax.set_xlabel("Latent Dimension $z_1$")
    ax.set_ylabel("Latent Dimension $z_2$")

    tick_locs = (np.arange(n) + 0.5) * image_size
    tick_labels = [f"{v:.2f}" for v in grid_x]
    ax.set_xticks(tick_locs)
    ax.set_xticklabels(tick_labels, rotation=45, fontsize=7)
    ax.set_yticks(tick_locs)
    ax.set_yticklabels([f"{v:.2f}" for v in grid_y], fontsize=7)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Saved manifold to {save_path}")
    return fig


def plot_iter_progression(history_images, history_iters, target_image, save_path=None):
    """
    Plot the iteration progression strip from slide 14:
    Iter 0 | Iter 10 | Iter 50 | ... | Target
    """
    n = len(history_images) + 1
    fig, axes = plt.subplots(1, n, figsize=(2.5 * n, 2.5))

    for ax, img, it in zip(axes[:-1], history_images, history_iters):
        img_np = img.squeeze(0).cpu().numpy()
        if img_np.shape[0] == 1:
            ax.imshow(img_np[0], cmap="gray")
        else:
            img_np = np.clip(img_np.transpose(1, 2, 0), 0, 1)
            ax.imshow(img_np)
        ax.set_title(f"Iter {it}")
        ax.axis("off")

    target_np = target_image.squeeze(0).cpu().numpy()
    if target_np.shape[0] == 1:
        axes[-1].imshow(target_np[0], cmap="gray")
    else:
        target_np = np.clip(target_np.transpose(1, 2, 0), 0, 1)
        axes[-1].imshow(target_np)
    axes[-1].set_title("Target Image")
    axes[-1].axis("off")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def plot_qualitative_grid(pairs, save_path=None):
    """
    Reproduces slide 15: pairs of (degraded, recovered) for each problem.

    pairs: list of (title_left, image_left, title_right, image_right)
    """
    n = len(pairs)
    fig, axes = plt.subplots(n, 2, figsize=(6, 3 * n))
    if n == 1:
        axes = axes[None, :]

    for row, (tl, il, tr, ir) in enumerate(pairs):
        for ax, t, img in [(axes[row, 0], tl, il), (axes[row, 1], tr, ir)]:
            img_np = img.squeeze(0).cpu().numpy()
            if img_np.shape[0] == 1:
                ax.imshow(img_np[0], cmap="gray")
            else:
                img_np = np.clip(img_np.transpose(1, 2, 0), 0, 1)
                ax.imshow(img_np)
            ax.set_title(t)
            ax.axis("off")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig
