"""
Variational Autoencoder for MNIST.

Encoder maps 28x28 images to a 2D latent space (so we can plot the
latent manifold). Decoder reconstructs from latent samples.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class VAE_MNIST(nn.Module):
    def __init__(self, latent_dim: int = 2, hidden_dim: int = 400):
        super().__init__()
        self.latent_dim = latent_dim

        # Encoder
        self.fc1 = nn.Linear(28 * 28, hidden_dim)
        self.fc_mu = nn.Linear(hidden_dim, latent_dim)
        self.fc_logvar = nn.Linear(hidden_dim, latent_dim)

        # Decoder
        self.fc2 = nn.Linear(latent_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, 28 * 28)

    def encode(self, x):
        h = F.relu(self.fc1(x.view(-1, 28 * 28)))
        return self.fc_mu(h), self.fc_logvar(h)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        h = F.relu(self.fc2(z))
        return torch.sigmoid(self.fc3(h)).view(-1, 1, 28, 28)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decode(z), mu, logvar


def vae_loss(recon_x, x, mu, logvar):
    """Reconstruction (BCE) + KL divergence to N(0, I)."""
    bce = F.binary_cross_entropy(
        recon_x.view(-1, 28 * 28), x.view(-1, 28 * 28), reduction="sum"
    )
    kld = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return bce + kld
