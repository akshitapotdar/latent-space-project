"""
StyleGAN2 wrapper for FFHQ.

Loads a pretrained StyleGAN2 from NVIDIA. Provides a clean interface
that matches our other generators so the inverse-problem solver can
treat all three (MNIST GAN, FFHQ VAE, StyleGAN2) the same way.

We optimize in W+ space rather than Z space — this is standard for
GAN inversion and gives much better reconstruction quality.

Requires: pip install stylegan2-pytorch  (or use NVIDIA's official repo)
"""
import torch
import torch.nn as nn

try:
    # Lazy import — only fails if user actually tries to load StyleGAN
    from stylegan2_pytorch import ModelLoader  # type: ignore
    HAS_STYLEGAN = True
except ImportError:
    HAS_STYLEGAN = False


class StyleGAN2FFHQ(nn.Module):
    """
    Thin wrapper around a pretrained StyleGAN2 generator.

    Two latent spaces are available:
      - Z space: 512-dim Gaussian input (what GANs traditionally use)
      - W+ space: 14 x 512 expanded latent (better for inversion)

    For inverse problems, optimize in W+ — the manifold is flatter
    and more disentangled there.
    """

    def __init__(self, checkpoint_path: str, image_size: int = 256):
        super().__init__()
        if not HAS_STYLEGAN:
            raise ImportError(
                "stylegan2-pytorch not installed. Run:\n"
                "  pip install stylegan2-pytorch\n"
                "Or use NVIDIA's official repo: "
                "https://github.com/NVlabs/stylegan2-ada-pytorch"
            )

        loader = ModelLoader(base_dir=checkpoint_path, image_size=image_size)
        self.G = loader.model.GAN.GE  # exponential moving avg generator
        self.G.eval()
        for p in self.G.parameters():
            p.requires_grad_(False)

        self.latent_dim = 512
        self.num_layers = self.G.num_layers
        self.image_size = image_size

    def sample_z(self, batch_size: int, device: str = "cuda"):
        return torch.randn(batch_size, self.latent_dim, device=device)

    def z_to_w(self, z):
        """Map Z to W using the mapping network."""
        return self.G.S(z)

    def sample_w_plus(self, batch_size: int, device: str = "cuda"):
        """Sample a W+ latent (num_layers copies of one W vector)."""
        z = self.sample_z(batch_size, device)
        w = self.z_to_w(z)
        # Expand to W+ (one w per layer)
        return w.unsqueeze(1).repeat(1, self.num_layers, 1)

    def forward(self, w_plus, noise=None):
        """Generate images from W+ latents. Output in [-1, 1]."""
        if noise is None:
            noise = torch.randn(
                w_plus.shape[0], self.image_size, self.image_size, 1,
                device=w_plus.device,
            )
        return self.G.G(w_plus, noise)
