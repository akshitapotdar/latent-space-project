"""
Latent-space optimization for inverse problems.

Implements the equation from slide 13:

    z* = argmin_z  L1( A(G(z)) - y )

We freeze the generator, take a random latent z, and run gradient
descent on z to make A(G(z)) match the observed measurement y.

Once z* is found, G(z*) gives us the recovered "clean" image.

This works for any differentiable generator and any differentiable
forward operator A — that's the whole point of using latent-space
priors for inverse problems.
"""
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import torch
import torch.nn.functional as F


@dataclass
class SolverResult:
    z_final: torch.Tensor
    image_final: torch.Tensor
    history_images: List[torch.Tensor] = field(default_factory=list)
    history_iters: List[int] = field(default_factory=list)
    history_loss: List[float] = field(default_factory=list)


def solve_inverse_problem(
    generator: Callable[[torch.Tensor], torch.Tensor],
    forward_op: Callable[[torch.Tensor], torch.Tensor],
    y: torch.Tensor,
    z_init: torch.Tensor,
    *,
    n_iters: int = 600,
    lr: float = 0.05,
    loss_type: str = "l1",
    snapshot_iters: Optional[List[int]] = None,
    z_lower: Optional[torch.Tensor] = None,
    z_upper: Optional[torch.Tensor] = None,
    verbose: bool = True,
) -> SolverResult:
    """
    Optimize z so that A(G(z)) ≈ y.

    Args:
        generator: any callable that maps z -> image. Must be differentiable
                   in z but its parameters should be frozen.
        forward_op: differentiable A() — e.g. mask, downsample, add noise
        y: observed (degraded) measurement
        z_init: starting point in latent space, shape (1, latent_dim)
        n_iters: gradient steps to take
        lr: Adam learning rate for z
        loss_type: 'l1' (matches the presentation) or 'l2'
        snapshot_iters: iterations at which to save the current G(z) image
                        — used for the iter-progression figure (slide 14)
        z_lower / z_upper: optional clamp box for z (useful to keep z in a
                           reasonable region of latent space)
    """
    # Make sure generator params are frozen — only z gets gradients
    if hasattr(generator, "parameters"):
        for p in generator.parameters():
            p.requires_grad_(False)

    z = z_init.detach().clone().requires_grad_(True)
    optimizer = torch.optim.Adam([z], lr=lr)

    if snapshot_iters is None:
        snapshot_iters = [0, 10, 50, 200, 325, 550]

    result = SolverResult(z_final=z, image_final=z)  # placeholder

    for it in range(n_iters + 1):
        optimizer.zero_grad()
        x_hat = generator(z)
        y_hat = forward_op(x_hat)

        if loss_type == "l1":
            loss = F.l1_loss(y_hat, y)
        elif loss_type == "l2":
            loss = F.mse_loss(y_hat, y)
        else:
            raise ValueError(f"Unknown loss_type {loss_type!r}")

        if it in snapshot_iters:
            result.history_images.append(x_hat.detach().cpu().clone())
            result.history_iters.append(it)
            result.history_loss.append(loss.item())

        if it == n_iters:
            break

        loss.backward()
        optimizer.step()

        if z_lower is not None or z_upper is not None:
            with torch.no_grad():
                if z_lower is not None:
                    z.clamp_(min=z_lower)
                if z_upper is not None:
                    z.clamp_(max=z_upper)

        if verbose and it % 50 == 0:
            print(f"  iter {it:4d} | loss {loss.item():.5f}")

    with torch.no_grad():
        result.z_final = z.detach()
        result.image_final = generator(z).detach()
    return result
