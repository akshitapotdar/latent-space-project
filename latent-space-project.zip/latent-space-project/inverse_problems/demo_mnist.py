"""
Same idea as demo_ffhq.py but on MNIST with the smaller GAN.

Reproduces the "Envisioned results" figure (slide 19) — recovering
a digit from blurry / occluded / noisy versions.

Usage:
    python -m inverse_problems.demo_mnist \
        --gan-checkpoint ./checkpoints/gan_mnist_G.pt
"""
import argparse
import os

import torch
import torchvision
from torchvision import datasets, transforms

from models import GAN_Generator_MNIST
from inverse_problems import (
    InpaintingOp, DownsampleOp, GaussianNoiseOp,
    make_random_mask, solve_inverse_problem,
)
from utils import plot_iter_progression, plot_qualitative_grid, mse


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--gan-checkpoint", required=True)
    p.add_argument("--out-dir", default="./results_mnist")
    p.add_argument("--latent-dim", type=int, default=2)
    p.add_argument("--n-iters", type=int, default=500)
    p.add_argument("--lr", type=float, default=0.05)
    p.add_argument("--target-idx", type=int, default=0,
                   help="Which MNIST test image to use as the target")
    args = p.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    os.makedirs(args.out_dir, exist_ok=True)

    G = GAN_Generator_MNIST(latent_dim=args.latent_dim).to(device)
    G.load_state_dict(torch.load(args.gan_checkpoint, map_location=device))
    G.eval()

    # Pick a target from MNIST test set
    test_set = datasets.MNIST(
        "./data", train=False, download=True,
        transform=transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,)),  # match generator's [-1, 1]
        ]),
    )
    x_true = test_set[args.target_idx][0].unsqueeze(0).to(device)

    H = 28
    rand_mask = make_random_mask(H, drop_prob=0.5, device=device, seed=0)

    problems = {
        "blurry": DownsampleOp(factor=4),
        "missing_patches": InpaintingOp(rand_mask),
        "noisy": GaussianNoiseOp(sigma=0.3, shape=x_true.shape, device=device),
    }

    z_init = torch.randn(1, args.latent_dim, device=device)
    pairs = []

    # Generator wrapper that handles batch-norm in eval mode for batch_size=1
    # (DCGAN with batchnorm needs at least 2 samples in train mode)
    def gen_fn(z):
        return G(z)

    for name, A in problems.items():
        print(f"=== {name} ===")
        y = A(x_true)
        result = solve_inverse_problem(
            generator=gen_fn, forward_op=A, y=y, z_init=z_init,
            n_iters=args.n_iters, lr=args.lr, loss_type="l1",
        )

        plot_iter_progression(
            [(im + 1) / 2 for im in result.history_images],
            result.history_iters,
            (x_true + 1) / 2,
            save_path=os.path.join(args.out_dir, f"{name}_iters.png"),
        )
        pairs.append((
            f"{name} (degraded)",
            ((y if y.shape == x_true.shape else x_true) + 1) / 2,
            "Closest match",
            (result.image_final + 1) / 2,
        ))
        print(f"  MSE: {mse(result.image_final, x_true):.5f}")

    plot_qualitative_grid(pairs, save_path=os.path.join(args.out_dir, "envisioned_results.png"))
    print(f"\nDone. Results in {args.out_dir}")


if __name__ == "__main__":
    main()
