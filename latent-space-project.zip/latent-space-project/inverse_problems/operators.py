"""
Forward / sensing operators A() for inverse problems.

Each operator takes a clean image x and produces a degraded
measurement y. They must be differentiable (so gradients flow
through them during latent-space optimization) and ideally
implemented as simple PyTorch ops.

These match the four operations evaluated in the presentation
(slide 16): super-resolution, large-occlusion inpainting,
small-occlusion inpainting (random pixels), and denoising.
"""
import torch
import torch.nn.functional as F


def make_box_mask(image_size: int, box_size: int, top: int, left: int, device="cpu"):
    """Single rectangular occlusion mask. 1 = visible, 0 = occluded."""
    mask = torch.ones(1, 1, image_size, image_size, device=device)
    mask[:, :, top:top + box_size, left:left + box_size] = 0.0
    return mask


def make_random_mask(image_size: int, drop_prob: float = 0.5, device="cpu", seed=None):
    """Per-pixel random mask (the salt-and-pepper-style occlusion in slide 15)."""
    g = torch.Generator(device=device)
    if seed is not None:
        g.manual_seed(seed)
    mask = (torch.rand(1, 1, image_size, image_size, generator=g, device=device) > drop_prob).float()
    return mask


class IdentityOp:
    """No degradation. Useful as a sanity check (slide 14, 'No destructive operation')."""
    def __call__(self, x):
        return x


class InpaintingOp:
    """Mask out pixels: y = mask * x. Mask broadcasts over batch and channels."""
    def __init__(self, mask):
        self.mask = mask  # shape (1, 1, H, W)

    def __call__(self, x):
        return self.mask.to(x.device) * x


class DownsampleOp:
    """Bilinear downsample for super-resolution problems."""
    def __init__(self, factor: int = 4):
        self.factor = factor

    def __call__(self, x):
        h, w = x.shape[-2:]
        return F.interpolate(
            x, size=(h // self.factor, w // self.factor),
            mode="bilinear", align_corners=False,
        )


class GaussianNoiseOp:
    """Add fixed Gaussian noise. The noise is sampled once and reused."""
    def __init__(self, sigma: float = 0.2, shape=None, device="cpu", seed=0):
        self.sigma = sigma
        if shape is not None:
            g = torch.Generator(device=device)
            g.manual_seed(seed)
            self.noise = sigma * torch.randn(shape, generator=g, device=device)
        else:
            self.noise = None

    def __call__(self, x):
        if self.noise is None:
            return x + self.sigma * torch.randn_like(x)
        return x + self.noise.to(x.device)
