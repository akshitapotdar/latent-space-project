"""
Reproduces slides 14 and 15: solving inverse problems on FFHQ
using a pretrained StyleGAN2 generator.

Solves four problems on the same target image:
    1. No degradation (sanity check / pure inversion)
    2. Large box occlusion (inpainting)
    3. Random pixel occlusion (inpainting, slide 15 lower-left)
    4. Super-resolution (4x downsample)
    5. Denoising (additive Gaussian noise)

Each solution backpropagates through W+ space of StyleGAN2.

Usage:
    # Make sure pretrained StyleGAN2 weights are downloaded first
    python -m inverse_problems.demo_ffhq \
        --stylegan-dir ./pretrained/stylegan2-ffhq \
        --target ./target_face.png \
        --out-dir ./results
"""
import argparse
import os

import torch
import torchvision.transforms as T
from PIL import Image

from models.stylegan_ffhq import StyleGAN2FFHQ
from inverse_problems import (
    IdentityOp, InpaintingOp, DownsampleOp, GaussianNoiseOp,
    make_box_mask, make_random_mask, solve_inverse_problem,
)
from utils import plot_iter_progression, plot_qualitative_grid, mse


def load_target(path: str, image_size: int, device: str):
    """Load and normalize a target image to match StyleGAN's [-1, 1] output."""
    img = Image.open(path).convert("RGB")
    transform = T.Compose([
        T.Resize(image_size),
        T.CenterCrop(image_size),
        T.ToTensor(),  # [0, 1]
    ])
    x = transform(img).unsqueeze(0).to(device)
    return x * 2 - 1  # -> [-1, 1]


def to_display(x):
    """Convert StyleGAN output back to [0, 1] for plotting."""
    return (x + 1) / 2


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--stylegan-dir", required=True)
    p.add_argument("--target", required=True)
    p.add_argument("--out-dir", default="./results")
    p.add_argument("--image-size", type=int, default=256)
    p.add_argument("--n-iters", type=int, default=600)
    p.add_argument("--lr", type=float, default=0.05)
    args = p.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    os.makedirs(args.out_dir, exist_ok=True)

    print("Loading StyleGAN2...")
    G = StyleGAN2FFHQ(args.stylegan_dir, image_size=args.image_size).to(device)

    print("Loading target image...")
    x_true = load_target(args.target, args.image_size, device)

    # Wrap generator so it takes a W+ latent and outputs an image directly
    def gen_fn(w_plus):
        return G(w_plus)

    # Initialize at the mean W+ — generally a reasonable starting point
    z_init = G.sample_w_plus(1, device=device)

    # --- Define each inverse problem ---
    H = args.image_size
    box_mask = make_box_mask(H, box_size=H // 4, top=H // 3, left=H // 4, device=device)
    rand_mask = make_random_mask(H, drop_prob=0.5, device=device, seed=0)

    problems = {
        "identity": IdentityOp(),
        "box_inpaint": InpaintingOp(box_mask),
        "random_inpaint": InpaintingOp(rand_mask),
        "super_res": DownsampleOp(factor=4),
        "denoise": GaussianNoiseOp(sigma=0.3, shape=x_true.shape, device=device, seed=0),
    }

    pairs = []
    metrics = {}

    for name, A in problems.items():
        print(f"\n=== Solving {name} ===")
        y = A(x_true)

        result = solve_inverse_problem(
            generator=gen_fn,
            forward_op=A,
            y=y,
            z_init=z_init,
            n_iters=args.n_iters,
            lr=args.lr,
            loss_type="l1",
        )

        # Iter-progression strip (slide 14 style)
        plot_iter_progression(
            [to_display(im) for im in result.history_images],
            result.history_iters,
            to_display(x_true),
            save_path=os.path.join(args.out_dir, f"{name}_iters.png"),
        )

        # Qualitative pair (slide 15 style)
        pairs.append((
            f"Degraded ({name})", to_display(y) if y.shape == x_true.shape else to_display(x_true),
            "Recovered", to_display(result.image_final),
        ))

        # Quantitative metric
        recovered = result.image_final
        metrics[name] = mse(to_display(recovered), to_display(x_true))
        print(f"  MSE vs ground truth: {metrics[name]:.5f}")

    # Combined qualitative figure
    plot_qualitative_grid(
        pairs, save_path=os.path.join(args.out_dir, "qualitative_grid.png"),
    )

    # Save metrics to a text file
    with open(os.path.join(args.out_dir, "metrics.txt"), "w") as f:
        f.write("Inverse problem MSE results (StyleGAN2 FFHQ)\n")
        f.write("=" * 50 + "\n")
        for name, val in metrics.items():
            f.write(f"  {name:20s}  MSE = {val:.5f}\n")

    print(f"\nDone. Results in {args.out_dir}")


if __name__ == "__main__":
    main()
